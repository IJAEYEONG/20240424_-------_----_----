import names from "./basic-data.js"
import {styles} from "./example-3.js"
const div =document.getElementById('root');
document.body.appendChild(div);

for(let property in styles.root)
{
  if(typeof styles[property] !== "object")
  {
    
  }
  
}

// for(let nIdx = 0 ; nIdx < div.children.length ; nIdx++)
// {
//   let child = div.children[nIdx];
// }


for(let i=0; i<=19; i++){
  const box = document.createElement('div')
  styles.root.children
  console.log(styles.root.children)

  box.innerHTML=names[i]
  
  div.appendChild(box)
}

